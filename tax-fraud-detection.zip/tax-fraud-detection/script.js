// Dark Mode Toggle
document.getElementById('dark-mode-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const icon = document.querySelector('#dark-mode-toggle i');
    icon.classList.toggle('fa-moon');
    icon.classList.toggle('fa-sun');
});

// Smooth Scrolling for CTA Button
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Show Section
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
        section.classList.add('hidden');
    });
    const targetSection = document.getElementById(sectionId);
    targetSection.classList.remove('hidden');
    targetSection.classList.add('active');
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('home-btn').addEventListener('click', () => showSection('home'));
    document.getElementById('search-btn').addEventListener('click', () => showSection('search'));
    document.getElementById('locality-btn').addEventListener('click', () => showSection('locality'));
    document.getElementById('fraud-btn').addEventListener('click', () => showSection('fraud'));
    document.getElementById('trends-btn').addEventListener('click', () => showSection('trends'));

    document.getElementById('fetch-taxpayers-btn').addEventListener('click', fetchTaxpayers);
    document.getElementById('export-taxpayers-btn').addEventListener('click', exportTaxpayers);
    document.getElementById('search-submit-btn').addEventListener('click', searchTaxpayer);
    document.getElementById('locality-submit-btn').addEventListener('click', localityAnalysis);
    document.getElementById('fraud-submit-btn').addEventListener('click', fetchFraudTaxpayers);
    document.getElementById('trends-submit-btn').addEventListener('click', fetchFraudTrends);
});

// Add Taxpayer
const BASE_URL = 'http://localhost:3000';

document.getElementById('taxpayer-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = {
        first_name: document.getElementById('first_name').value,
        last_name: document.getElementById('last_name').value,
        email: document.getElementById('email').value,
        phone_no: document.getElementById('phone_no').value,
        address: document.getElementById('address').value,
        city: document.getElementById('city').value,
        state: document.getElementById('state').value,
        country: document.getElementById('country').value,
        dob: document.getElementById('dob').value,
        occupation: document.getElementById('occupation').value,
        marital_stat: document.getElementById('marital_stat').value,
        employment_stat: document.getElementById('employment_stat').value,
        ssn: document.getElementById('ssn').value,
        salary: parseFloat(document.getElementById('salary').value)
    };

    try {
        const response = await fetch(`${BASE_URL}/taxpayers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            const result = await response.json();
            throw new Error(result.error || 'Failed to add taxpayer');
        }

        const result = await response.json();
        document.getElementById('form-message').textContent = 'Taxpayer added successfully!';
        document.getElementById('form-message').style.background = '#d4edda';
        document.getElementById('taxpayer-form').reset();
    } catch (error) {
        console.error('Add taxpayer error:', error);
        document.getElementById('form-message').textContent = `Error: ${error.message}`;
        document.getElementById('form-message').style.background = '#f8d7da';
    }
});

// Fetch Taxpayers
async function fetchTaxpayers() {
    try {
        const response = await fetch(`${BASE_URL}/taxpayers`);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const taxpayers = await response.json();
        const list = document.getElementById('taxpayer-list');
        list.innerHTML = '<h3>Taxpayers List</h3>';
        if (taxpayers.length === 0) {
            list.innerHTML += '<p>No taxpayers found</p>';
        } else {
            taxpayers.forEach(t => {
                const div = document.createElement('div');
                const formattedSalary = t.salary != null ? `$${t.salary.toFixed(2)}` : 'N/A';
                div.textContent = `${t.first_name} ${t.last_name} - ${t.email} - ${t.phone_no} - ${t.city} - Salary: ${formattedSalary}`;
                list.appendChild(div);
            });
        }
    } catch (error) {
        console.error('Fetch taxpayers error:', error);
        document.getElementById('taxpayer-list').textContent = `Error fetching taxpayers: ${error.message}`;
    }
}

// Export Taxpayers
function exportTaxpayers() {
    fetch(`${BASE_URL}/taxpayers`)
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            const csv = Papa.unparse(data);
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'taxpayers.csv';
            link.click();
        })
        .catch(error => {
            console.error('Export taxpayers error:', error);
            alert(`Error exporting taxpayers: ${error.message}`);
        });
}

// Search Taxpayer
async function searchTaxpayer() {
    const name = document.getElementById('search-name').value;
    const phone = document.getElementById('search-phone').value;
    try {
        const response = await fetch(`${BASE_URL}/search-taxpayer?name=${name}${phone ? `&phone=${phone}` : ''}`);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const results = await response.json();
        const searchResults = document.getElementById('search-results');
        searchResults.innerHTML = '<h3>Search Results</h3>';
        if (results.length === 0) {
            searchResults.innerHTML += '<p>No taxpayers found</p>';
        } else {
            results.forEach(t => {
                const div = document.createElement('div');
                const formattedSalary = t.salary != null ? `$${t.salary.toFixed(2)}` : 'N/A';
                div.textContent = `${t.first_name} ${t.last_name} - ${t.email} - ${t.phone_no} - ${t.city} - Salary: ${formattedSalary}`;
                searchResults.appendChild(div);
            });
        }
    } catch (error) {
        console.error('Search taxpayer error:', error);
        document.getElementById('search-results').textContent = `Error searching taxpayers: ${error.message}`;
    }
}

// Fetch Fraudulent Taxpayers
async function fetchFraudTaxpayers() {
    const cityFilter = document.getElementById('fraud-city-filter').value.toLowerCase();
    try {
        const response = await fetch(`${BASE_URL}/fraudulent-taxpayers`);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        let taxpayers = await response.json();
        if (cityFilter) {
            taxpayers = taxpayers.filter(t => t.city.toLowerCase().includes(cityFilter));
        }
        const list = document.getElementById('fraud-list');
        list.innerHTML = '<h3>Fraudulent Taxpayers</h3>';
        if (taxpayers.length === 0) {
            list.innerHTML += '<p>No fraudulent taxpayers found</p>';
        } else {
            taxpayers.forEach(t => {
                const div = document.createElement('div');
                const formattedSalary = t.salary != null ? `$${t.salary.toFixed(2)}` : 'N/A';
                div.textContent = `${t.first_name} ${t.last_name} - ${t.email} - ${t.phone_no} - ${t.city} - Salary: ${formattedSalary}`;
                list.appendChild(div);
            });
        }
    } catch (error) {
        console.error('Fetch fraudulent taxpayers error:', error);
        document.getElementById('fraud-list').textContent = `Error fetching fraudulent taxpayers: ${error.message}`;
    }
}

// Fetch Fraud Trends
async function fetchFraudTrends() {
    try {
        const response = await fetch(`${BASE_URL}/fraud-trends`);
        console.log('Response status:', response.status);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const trends = await response.json();
        console.log('Fetched fraud trends:', trends);

        const ctx = document.getElementById('trends-chart').getContext('2d');
        if (window.trendsChart) {
            window.trendsChart.destroy();
        }

        const chartContainer = document.getElementById('trends-chart').parentElement;
        chartContainer.innerHTML = '<canvas id="trends-chart"></canvas>';
        const newCtx = document.getElementById('trends-chart').getContext('2d');

        if (!trends || !Array.isArray(trends) || trends.length === 0) {
            chartContainer.innerHTML = '<p>No fraud trends data available.</p>';
            console.log('No trends data to display');
            return;
        }

        const labels = trends.map(t => t.month);
        const data = trends.map(t => t.fraud_count);
        console.log('Chart labels:', labels);
        console.log('Chart data:', data);

        window.trendsChart = new Chart(newCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Fraud Incidents',
                    data: data,
                    borderColor: '#ff6f61',
                    backgroundColor: 'rgba(255, 111, 97, 0.2)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: 'Fraud Trends Over Time' }
                },
                scales: {
                    x: { title: { display: true, text: 'Month' } },
                    y: {
                        title: { display: true, text: 'Fraud Count' },
                        beginAtZero: true,
                        suggestedMax: 100
                    }
                }
            }
        });
    } catch (error) {
        console.error('Fetch fraud trends error:', error);
        const chartContainer = document.getElementById('trends-chart').parentElement;
        chartContainer.innerHTML = `<p>Error fetching fraud trends: ${error.message}</p>`;
    }
}

// Locality Analysis
async function localityAnalysis() {
    const city = document.getElementById('locality-city').value;
    if (!city) {
        alert('Please enter a city to analyze.');
        return;
    }
    try {
        const response = await fetch(`${BASE_URL}/locality-analysis?city=${city}`);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        const ctx = document.getElementById('locality-chart').getContext('2d');
        if (window.localityChart) {
            window.localityChart.destroy();
        }
        window.localityChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Fraudulent', 'Non-Fraudulent'],
                datasets: [{
                    data: [data.fraud_count, data.total_taxpayers - data.fraud_count],
                    backgroundColor: ['#ff6f61', '#36a2eb']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: `Fraud Analysis in ${city}` }
                }
            }
        });
    } catch (error) {
        console.error('Locality analysis error:', error);
        alert(`Error in locality analysis: ${error.message}`);
    }
}